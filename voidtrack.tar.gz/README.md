Nir Boneh nibo0582 Brian Kidd brki3609 CSCI 5239

Present Void Track, try to not fall off from the track as the spaceship speeds up with every zone.

Requires OpenAL (use the following to install):
sudo apt-get install libopenal-dev

Controls:
right/left arrow keys - turn 
space - jump (hold for big jump, tap for short hop)
p - pause (Use arrow keys to look around) cannot be used in countdown or gameover or victory screen
ESC - exit

Took 100+ hours